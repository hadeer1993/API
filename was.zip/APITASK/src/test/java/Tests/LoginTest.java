package Tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseBodyData;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Predicate;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.specification.RequestSenderOptions;
import net.bytebuddy.asm.Advice.Return;

import static io.restassured.RestAssured.given;

public class LoginTest {
			
		@Test(priority=1)
		public  void Login(){
		 given()
			.contentType("multipart/form-data")
			.multiPart("email","was@was.com")
            .multiPart("password","admin12345")
            
			.when()
			  .post("https://was-api-dev.ibtik.com/api/v1/admin/login")
			  
			.then()
			  .statusCode(200)
			  .log()
			  .all()
			  .extract()
			  .response()
			  .body();			
		}
		}



   

