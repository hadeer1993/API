package Tests;
import static io.restassured.RestAssured.given;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Predicate;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import okhttp3.Response;

import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

public class GettingResource {
	@Test(priority=1)
	public  void GettingResource(){
	 given()
		.contentType("multipart/form-data")
        
		.when()
		  .get("https://jsonplaceholder.typicode.com/posts/1")
		  
		.then()
		  .statusCode(200)
		  .log()
		  .all()
		  .extract()
		  .response()
		  .body();			
	}
	}


