package Tests;
import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Predicate;

import io.restassured.specification.RequestSpecification;
import net.minidev.json.JSONObject;

import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;
public class CreatingResource {
	@Test(priority=1)
	public void testCreatePost() {
	    String title = "YALLA Plus";
	    String body = "YALLA Plus";
	    int userId = 1;

	    Response response = RestAssured.given()
	            .contentType(ContentType.JSON)
	            .body("{\"title\":\"" + title + "\",\"body\":\"" + body + "\",\"userId\":" + userId + "}")
	            .post("https://jsonplaceholder.typicode.com/posts");

	    response.then().statusCode(201);

	    // You can also extract the response body and validate it
	    String responseBody = response.getBody().asString();
	    System.out.println(responseBody);
	}


}
