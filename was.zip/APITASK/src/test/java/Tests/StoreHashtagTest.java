package Tests;
import static io.restassured.RestAssured.given;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Predicate;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import okhttp3.Response;

import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;
public class StoreHashtagTest {
	
	static String token;
	 
	@Test
	public void getToken()
	{
		RestAssured.baseURI="https://was-api-dev.ibtik.com/api/v1";
		RequestSpecification request = RestAssured.given();
		String payload ="{\r\n" + 
				"    \"email\": \"was@was.com\",\r\n" + 
				"    \"password\": \"admin12345\",\r\n" + 
				"    \"client_id\":  \"967710db-f2f2-46ca-8aaf-07d4f1d75c69\",\r\n" + 
				"    \"client_secret\":  \"gTCcpRhE9bmhme9aEPnj5j2D05p4sJkufBtpYSkb\"\r\n" + 
				"}";
		request.header("Content-Type","application/json");
		io.restassured.response.Response responseFromToken = request.body(payload).post("/admin/login");
		String jsonResponse=responseFromToken.getBody().asString();
		token = io.restassured.path.json.JsonPath.from(jsonResponse).get("access_token");
		System.out.println(token);
	}

	
		@Test(priority=1)
		public static void Storehashtag(){
			
		   given()
			.contentType("multipart/form-data")
			.multiPart("name", "Sports")
			.multiPart("local", "en")
			.header("Authorization", "bearer" + token)
			
			.when()
			  .get("https://was-api-dev.ibtik.com/api/v1/admin/hashtags")
			  
			.then()
			  .statusCode(200)
			  .log()
			  .all()
			  .extract()
			  .response()
			  .body();	

		}
	}


